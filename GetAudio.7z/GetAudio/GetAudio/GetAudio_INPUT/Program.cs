﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Harman.CheckIt.Audio;
using System.Linq;

namespace Harman.CCMedia.MidAudio.AudioControl
{
    class GetAudioValues
    {
        static void Main(string[] args)
        {
            List<BassAudioChannelIn> inputChannels = BassAudio.GetInChannels();
            if (inputChannels.Count <= 0)
            {
                MessageBox.Show("No one channel! Please Check Input Channel !");
            }
            else
            {
                Console.WriteLine("Total channel count: " + inputChannels.Count + " \n" + String.Join("\n", inputChannels.Select(T => T.ToString()).ToArray()) + "\n===================================");


                //for channal 1
                //GetChannel1(inputChannels);

                //for channal 2
                GetChannel2(inputChannels);

                //Console.ReadKey();
            }
 
        }

        public static void GetChannel1(List<BassAudioChannelIn> inputChannels)
        {
            //get the specified channel by name: 1-2 (*OCTA-CAPTURE) (Left) --> For Roland Interface;   Microphone (* US-2x2) (Left) --> For TASCAM Interface
            inputChannels = inputChannels.Where(c => (c.ToString().Trim().StartsWith("1-2 (") && c.ToString().Trim().EndsWith("OCTA-CAPTURE) (Left)")) ||
            (c.ToString().Trim().StartsWith("Microphone (") && c.ToString().Trim().EndsWith("US-2x2) (Left)"))).ToList();
            if (inputChannels.Count < 1)
            {
                MessageBox.Show("No channel returned with the name 1-2 (*OCTA-CAPTURE) (Left) or Microphone (* US-2x2) (Left)");
            }
            else if (inputChannels.Count > 1)
            {
                MessageBox.Show(inputChannels.Count + " channels with the name 1-2 (*OCTA-CAPTURE) (Left) or Microphone (* US-2x2) (Left), Please check your environment!");
            }
            else
            {
                double frequency = inputChannels[0].GetFrequency();
                double amplitude = inputChannels[0].GetAmplitudeRms();
                Console.WriteLine("frequency & amplitude \n" + frequency + "\n" + amplitude);

            }
        }

        public static void GetChannel2(List<BassAudioChannelIn> inputChannels)
        {
            inputChannels = inputChannels.Where(c => (c.ToString().Trim().StartsWith("1-2 (") && c.ToString().Trim().EndsWith("OCTA-CAPTURE) (Right)")) ||
               (c.ToString().Trim().StartsWith("Microphone (") && c.ToString().Trim().EndsWith("US-2x2) (Right)"))).ToList();
            if (inputChannels.Count < 1)
            {
                MessageBox.Show("No channel returned with the name 1-2 (*OCTA-CAPTURE) (Right) or Microphone (* US-2x2) (Right)");
            }
            else if (inputChannels.Count > 1)
            {
                MessageBox.Show(inputChannels.Count + " channels with the name 1-2 (*OCTA-CAPTURE) (Right) or Microphone (* US-2x2) (Right), Please check your environment!");
            }
            else
            {
                double frequency = inputChannels[0].GetFrequency();
                double amplitude = inputChannels[0].GetAmplitudeRms();
                Console.WriteLine("frequency & amplitude \n" + frequency + "\n" + amplitude);

            }
        }

        public double ErrorRange(double amplitude1, double amplitude2)
        {
            double amplitude = 0;
            if (amplitude1 != 0 && amplitude2 != 0)
            {
                if (System.Math.Abs(amplitude1 - amplitude2) < amplitude1 / 20)
                {
                    amplitude = (amplitude1 + amplitude2) / 2;
                }
                else
                {
                    //TODO
                }
            }
            else
            {
                //TODO
            }
            return amplitude;
        }
    }
}